x = int (input("X = "))

f = 3*x**3 - 12*x**2 + (7/15)*x - 22/7
print ("Hasilnya adalah",f)
